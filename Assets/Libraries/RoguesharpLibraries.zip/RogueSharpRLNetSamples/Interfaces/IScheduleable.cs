﻿namespace RogueSharpRLNetSamples.Interfaces
{
   public interface IScheduleable
   {
      int Time { get; }
   }
}