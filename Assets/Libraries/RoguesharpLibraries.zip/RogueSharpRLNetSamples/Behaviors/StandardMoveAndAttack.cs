﻿using System;
using RogueSharp;
using RogueSharpRLNetSamples.Core;
using RogueSharpRLNetSamples.Interfaces;
using RogueSharpRLNetSamples.Systems;
using UnityEngine;

namespace RogueSharpRLNetSamples.Behaviors
{
   public class StandardMoveAndAttack : IBehavior
   {
      public bool Act( Monster monster, CommandSystem commandSystem )
      {
            Player player = commandSystem.dungeonMap.player;
         FieldOfView monsterFov = new FieldOfView( commandSystem.dungeonMap );
         if ( !monster.TurnsAlerted.HasValue )
         {
            monsterFov.ComputeFov( monster.X, monster.Y, monster.Awareness, true );
            if ( monsterFov.IsInFov( player.X, player.Y ) )
            {
               //Debug.Log( "Monster is eager to fight player" );
               monster.TurnsAlerted = 1;
            }
         }
         if ( monster.TurnsAlerted.HasValue )
         {
            commandSystem.dungeonMap.SetIsWalkable( monster.X, monster.Y, true );
            commandSystem.dungeonMap.SetIsWalkable( player.X, player.Y, true );

            PathFinder pathFinder = new PathFinder( commandSystem.dungeonMap );
            Path path = null;

            try
            {
               path = pathFinder.ShortestPath( commandSystem.dungeonMap.GetCell( monster.X, monster.Y ), commandSystem.dungeonMap.GetCell( player.X, player.Y ) );
            }
            catch ( PathNotFoundException )
            {
               //Debug.Log( "monster waits for a turn" );
            }

            commandSystem.dungeonMap.SetIsWalkable( monster.X, monster.Y, false );
            commandSystem.dungeonMap.SetIsWalkable( player.X, player.Y, false );

            if ( path != null )
            {
               try
               {
                  commandSystem.MoveMonster( monster, (Cell)path.StepForward() );
               }
               catch ( NoMoreStepsException )
               {
                  //Debug.Log( "monster decides to wait for a turn" );
               }
            }

            monster.TurnsAlerted++;

            // Lose alerted status every 15 turns. As long as the player is still in FoV the monster will be realerted otherwise the monster will quit chasing the player.
            if ( monster.TurnsAlerted > 15 )
            {
               monster.TurnsAlerted = null;
            }
         }
         return true;
      }
   }
}
